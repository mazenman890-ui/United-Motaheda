import React, { useCallback, useEffect } from "react";
import { I18nManager, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { Stack, useRouter, usePathname } from "expo-router";
import { SafeAreaProvider, useSafeAreaInsets } from "react-native-safe-area-context";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
} from "react-native-reanimated";
import {
  useFonts,
  Cairo_400Regular,
  Cairo_600SemiBold,
  Cairo_700Bold,
  Cairo_800ExtraBold,
  Cairo_900Black,
} from "@expo-google-fonts/cairo";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { useCartStore } from "@/stores/cart";
import { useOrderStore } from "@/stores/orders";
import { useWishlistStore } from "@/stores/wishlist";
import { useNotificationStore, selectUnreadCount } from "@/stores/notifications";
import { NotificationBanner } from "@/components/NotificationBanner";
import { theme } from "@/theme";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime:            5 * 60 * 1000,
      gcTime:               15 * 60 * 1000,
      retry:                1,
      refetchOnWindowFocus: false,
      refetchOnMount:       false,
    },
  },
});

// ─── Notification sync — subscribes/unsubscribes with auth state ──────────────

function NotificationSync() {
  const { user }    = useAuth();
  const fetch       = useNotificationStore((s) => s.fetch);
  const subscribe   = useNotificationStore((s) => s.subscribe);
  const reset       = useNotificationStore((s) => s.reset);

  useEffect(() => {
    if (!user) {
      reset();
      return;
    }
    fetch(user.id);
    subscribe(user.id);
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  return null;
}

// ─── Floating notification bell — always visible ─────────────────────────────

const HIDDEN_PATHS = ["/notifications", "/checkout", "/(auth)", "/onboarding"];

function FloatingNotificationBell() {
  const insets      = useSafeAreaInsets();
  const router      = useRouter();
  const pathname    = usePathname();
  const { user }    = useAuth();
  const unread      = useNotificationStore(selectUnreadCount);
  const scale       = useSharedValue(1);

  const bellAnim = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePress = useCallback(() => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    scale.value = withSequence(
      withSpring(0.85, { damping: 12, stiffness: 400 }),
      withSpring(1.15, { damping: 14, stiffness: 300 }),
      withSpring(1.0,  { damping: 16, stiffness: 280 }),
    );
    router.push("/notifications");
  }, [router, scale]);

  if (!user) return null;
  if (HIDDEN_PATHS.some((p) => pathname.startsWith(p))) return null;

  return (
    <Animated.View style={[floatStyles.container, { top: insets.top + 10 }, bellAnim]}>
      <Pressable onPress={handlePress} style={floatStyles.btn} hitSlop={8}>
        <Ionicons name="notifications-outline" size={19} color={theme.colors.slate[700]} />
        {unread > 0 && (
          <View style={floatStyles.badge}>
            <Text style={floatStyles.badgeText}>{unread > 9 ? "9+" : unread}</Text>
          </View>
        )}
      </Pressable>
    </Animated.View>
  );
}

const floatStyles = StyleSheet.create({
  container: {
    position:  "absolute",
    left:      14,
    zIndex:    900,
  },
  btn: {
    width:           42,
    height:          42,
    borderRadius:    14,
    backgroundColor: "rgba(255,255,255,0.95)",
    alignItems:      "center",
    justifyContent:  "center",
    ...theme.shadow.md,
    borderWidth:     1,
    borderColor:     theme.colors.border.medium,
  },
  badge: {
    position:          "absolute",
    top:               -3,
    right:             -3,
    backgroundColor:   theme.colors.error.base,
    borderRadius:      8,
    minWidth:          16,
    height:            16,
    alignItems:        "center",
    justifyContent:    "center",
    paddingHorizontal: 3,
    borderWidth:       1.5,
    borderColor:       "#fff",
  },
  badgeText: {
    color:      "#fff",
    fontSize:   8,
    fontFamily: theme.fonts.black,
    lineHeight: 11,
  },
});

// ─── Root layout ──────────────────────────────────────────────────────────────

export default function RootLayout() {
  const hydrate         = useCartStore((s) => s.hydrate);
  const hydrateOrders   = useOrderStore((s) => s.hydrate);
  const hydrateWishlist = useWishlistStore((s) => s.hydrate);

  const [fontsLoaded] = useFonts({
    Cairo_400Regular,
    Cairo_600SemiBold,
    Cairo_700Bold,
    Cairo_800ExtraBold,
    Cairo_900Black,
  });

  useEffect(() => {
    if (!fontsLoaded) return;
    if (!I18nManager.isRTL) I18nManager.forceRTL(true);
    Promise.all([hydrate(), hydrateOrders(), hydrateWishlist()])
      .catch(() => {})
      .finally(() => SplashScreen.hideAsync());
  }, [fontsLoaded, hydrate, hydrateOrders, hydrateWishlist]);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <StatusBar style="light" />
            <NotificationSync />
            <FloatingNotificationBell />
            <Stack screenOptions={{ headerShown: false, animation: "fade" }}>
              <Stack.Screen name="index"                  options={{ headerShown: false }} />
              <Stack.Screen name="onboarding"             options={{ headerShown: false, animation: "fade" }} />
              <Stack.Screen name="(tabs)"                 options={{ headerShown: false }} />
              <Stack.Screen name="(auth)"                 options={{ headerShown: false, presentation: "modal", animation: "slide_from_bottom" }} />
              <Stack.Screen name="product/[id]"           options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="category/[id]"          options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="checkout"               options={{ headerShown: false, presentation: "modal", animation: "slide_from_bottom" }} />
              <Stack.Screen name="orders"                 options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="favorites"              options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="addresses"              options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="notifications/index"    options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="notifications/[id]"     options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="loyalty"                 options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="about"                  options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="privacy"                options={{ headerShown: false, animation: "slide_from_right" }} />
              <Stack.Screen name="terms"                  options={{ headerShown: false, animation: "slide_from_right" }} />
            </Stack>
            <NotificationBanner />
          </AuthProvider>
        </QueryClientProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
