import React, { memo, useCallback } from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  FadeIn,
} from "react-native-reanimated";
import { theme } from "@/theme";
import { Badge } from "./ui/Badge";
import { useCartStore } from "@/stores/cart";
import { useWishlistStore } from "@/stores/wishlist";
import type { NativeProduct } from "@/services/productsApi";

interface ProductCardProps {
  product:  NativeProduct;
  onPress?: () => void;
  lang?:    "ar" | "en";
  variant?: "grid" | "row";
}

const AnimPressable = Animated.createAnimatedComponent(Pressable);

export const ProductCard = memo(function ProductCard({
  product,
  onPress,
  lang    = "ar",
  variant = "grid",
}: ProductCardProps) {
  const addItem    = useCartStore((s) => s.addItem);
  const cartItems  = useCartStore((s) => s.items);
  const inCart     = cartItems.some((i) => i.productId === product.id);
  const cartQty    = cartItems.find((i) => i.productId === product.id)?.quantity ?? 0;

  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const inWishlist     = useWishlistStore((s) => s.has(product.id));

  const scale    = useSharedValue(1);
  const btnScale = useSharedValue(1);
  const hrtScale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const btnStyle  = useAnimatedStyle(() => ({
    transform:       [{ scale: btnScale.value }],
    backgroundColor: inCart ? theme.colors.brand[600] : theme.colors.brand[50],
  }));
  const hrtStyle = useAnimatedStyle(() => ({
    transform: [{ scale: hrtScale.value }],
  }));

  const onPressIn  = () => { scale.value = withSpring(0.97, theme.animation.spring.snappy); };
  const onPressOut = () => { scale.value = withSpring(1,    theme.animation.spring.snappy); };

  const handleAddToCart = useCallback(() => {
    if (!product.inStock) return;
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    btnScale.value = withSequence(
      withSpring(0.82, theme.animation.spring.stiff),
      withSpring(1.14, theme.animation.spring.bouncy),
      withSpring(1,    theme.animation.spring.default),
    );
    addItem(product, 1);
  }, [product, addItem, btnScale]);

  const handleWishlist = useCallback(() => {
    if (Platform.OS !== "web") {
      inWishlist
        ? Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
        : Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    hrtScale.value = withSequence(
      withSpring(0.75, theme.animation.spring.stiff),
      withSpring(1.3,  theme.animation.spring.bouncy),
      withSpring(1,    theme.animation.spring.default),
    );
    toggleWishlist(product);
  }, [product, toggleWishlist, hrtScale, inWishlist]);

  const displayName = lang === "ar"
    ? (product.nameAr ?? product.name)
    : (product.nameEn ?? product.name);

  const priceStr = `${product.price.toFixed(2)} ج.م`;

  // ── Grid variant ───────────────────────────────────────────────────────────
  if (variant === "grid") {
    return (
      <AnimPressable
        entering={FadeIn}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        onPress={onPress}
        style={[cardStyle, styles.gridCard]}>

        {/* Image area */}
        <View style={styles.imgBox}>
          {product.imageUrl ? (
            <Image
              source={{ uri: product.imageUrl }}
              style={StyleSheet.absoluteFill}
              contentFit="contain"
              transition={200}
            />
          ) : (
            <View style={styles.imgPlaceholder}>
              <Ionicons name="medkit-outline" size={40} color={theme.colors.slate[300]} />
            </View>
          )}

          {/* Out of stock overlay */}
          {!product.inStock && (
            <View style={styles.outOfStockOverlay}>
              <Badge variant="neutral">نفذ المخزون</Badge>
            </View>
          )}

          {/* Cart qty badge */}
          {inCart && (
            <Animated.View entering={FadeIn.duration(180)} style={styles.qtyBadge}>
              <Text style={styles.qtyText}>{cartQty}</Text>
            </Animated.View>
          )}

          {/* Wishlist button */}
          <Animated.View style={[styles.heartBtn, hrtStyle]}>
            <Pressable onPress={handleWishlist} hitSlop={6} style={styles.heartPressable}>
              <Ionicons
                name={inWishlist ? "heart" : "heart-outline"}
                size={15}
                color={inWishlist ? theme.colors.rose[500] : theme.colors.slate[400]}
              />
            </Pressable>
          </Animated.View>
        </View>

        {/* Info */}
        <View style={styles.gridInfo}>
          <Text style={styles.catLabel} numberOfLines={1}>{product.categoryName}</Text>
          <Text style={styles.nameLabel} numberOfLines={2}>{displayName}</Text>

          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>{priceStr}</Text>
            <Animated.View style={[btnStyle, styles.addBtn]}>
              <Pressable onPress={handleAddToCart} disabled={!product.inStock} hitSlop={8}>
                <Ionicons
                  name={inCart ? "checkmark" : "add"}
                  size={18}
                  color={inCart ? "#fff" : theme.colors.brand[600]}
                />
              </Pressable>
            </Animated.View>
          </View>
        </View>
      </AnimPressable>
    );
  }

  // ── Row variant ────────────────────────────────────────────────────────────
  return (
    <AnimPressable
      onPressIn={onPressIn}
      onPressOut={onPressOut}
      onPress={onPress}
      style={[cardStyle, styles.rowCard]}>

      <View style={styles.rowThumb}>
        {product.imageUrl ? (
          <Image source={{ uri: product.imageUrl }} style={StyleSheet.absoluteFill} contentFit="contain" transition={200} />
        ) : (
          <View style={styles.imgPlaceholder}>
            <Ionicons name="medkit-outline" size={28} color={theme.colors.slate[300]} />
          </View>
        )}
      </View>

      <View style={styles.rowInfo}>
        <Text style={styles.catLabel} numberOfLines={1}>{product.categoryName}</Text>
        <Text style={[styles.nameLabel, { fontSize: theme.fontSize.md }]} numberOfLines={2}>{displayName}</Text>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 4 }}>
          <Text style={styles.priceLabel}>{priceStr}</Text>
          {!product.inStock && <Badge variant="neutral" size="sm">نفذ</Badge>}
        </View>
      </View>

      <View style={styles.rowActions}>
        <Animated.View style={hrtStyle}>
          <Pressable onPress={handleWishlist} hitSlop={6} style={[styles.rowActionBtn, inWishlist && styles.rowActionBtnActive]}>
            <Ionicons
              name={inWishlist ? "heart" : "heart-outline"}
              size={16}
              color={inWishlist ? theme.colors.rose[500] : theme.colors.slate[400]}
            />
          </Pressable>
        </Animated.View>
        <Animated.View style={[btnStyle, styles.rowActionBtn]}>
          <Pressable onPress={handleAddToCart} disabled={!product.inStock} hitSlop={6}>
            <Ionicons name={inCart ? "checkmark" : "add"} size={18} color={inCart ? "#fff" : theme.colors.brand[600]} />
          </Pressable>
        </Animated.View>
      </View>
    </AnimPressable>
  );
});

const styles = StyleSheet.create({
  // Grid
  gridCard:         { backgroundColor: theme.colors.surface, borderRadius: theme.layout.cardRadius, overflow: "hidden", ...theme.shadow.card, borderWidth: 1, borderColor: theme.colors.border.default },
  imgBox:           { height: 152, backgroundColor: theme.colors.subtle, position: "relative" },
  imgPlaceholder:   { flex: 1, alignItems: "center", justifyContent: "center" },
  outOfStockOverlay:{ ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(248,250,252,0.88)", alignItems: "center", justifyContent: "center" },
  qtyBadge:         { position: "absolute", top: 8, left: 8, backgroundColor: theme.colors.brand[600], borderRadius: theme.radius.full, minWidth: 22, height: 22, alignItems: "center", justifyContent: "center", paddingHorizontal: 5 },
  qtyText:          { color: "#fff", fontSize: 10, fontFamily: theme.fonts.black },
  heartBtn:         { position: "absolute", top: 8, right: 8 },
  heartPressable:   { width: 28, height: 28, borderRadius: 9, backgroundColor: "rgba(255,255,255,0.92)", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: theme.colors.border.default },
  gridInfo:         { padding: 12, gap: 3 },
  catLabel:         { fontSize: 10, fontFamily: theme.fonts.regular, color: theme.colors.text.tertiary, textAlign: "right" },
  nameLabel:        { fontSize: theme.fontSize.sm, fontFamily: theme.fonts.bold, color: theme.colors.text.primary, textAlign: "right", lineHeight: 18 },
  priceRow:         { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 6 },
  priceLabel:       { fontSize: theme.fontSize.md, fontFamily: theme.fonts.black, color: theme.colors.brand[700] },
  addBtn:           { width: 34, height: 34, borderRadius: theme.radius.md, alignItems: "center", justifyContent: "center" },
  // Row
  rowCard:          { flexDirection: "row-reverse", alignItems: "center", gap: 12, backgroundColor: theme.colors.surface, borderRadius: theme.layout.cardRadius, padding: 12, ...theme.shadow.card, borderWidth: 1, borderColor: theme.colors.border.default },
  rowThumb:         { width: 72, height: 72, borderRadius: theme.radius.lg, overflow: "hidden", backgroundColor: theme.colors.subtle, position: "relative" },
  rowInfo:          { flex: 1, gap: 2 },
  rowActions:       { gap: 8, alignItems: "center" },
  rowActionBtn:     { width: 36, height: 36, borderRadius: theme.radius.md, alignItems: "center", justifyContent: "center", backgroundColor: theme.colors.brand[50], borderWidth: 1, borderColor: theme.colors.brand[100] },
  rowActionBtnActive: { backgroundColor: theme.colors.rose[50], borderColor: theme.colors.rose[100] },
});
