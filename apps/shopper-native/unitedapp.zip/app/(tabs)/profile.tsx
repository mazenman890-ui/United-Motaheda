import React, { useCallback, useState } from "react";
import {
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { useAuth } from "@/contexts/AuthContext";
import { useCartStore } from "@/stores/cart";
import { useWishlistStore } from "@/stores/wishlist";
import { useOrderStore } from "@/stores/orders";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { theme } from "@/theme";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

interface MenuItemProps {
  icon:    IoniconsName;
  label:   string;
  badge?:  string | number;
  onPress: () => void;
  danger?: boolean;
  color?:  string;
}

function MenuItem({ icon, label, badge, onPress, danger = false, color }: MenuItemProps) {
  const ic = danger ? theme.colors.error.base : (color ?? theme.colors.brand[600]);

  const handlePress = useCallback(() => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
    onPress();
  }, [onPress]);

  return (
    <Pressable onPress={handlePress} style={({ pressed }) => [styles.item, pressed && { opacity: 0.7 }]}>
      <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12, flex: 1 }}>
        <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: danger ? theme.colors.error.bg : `${ic}14`, alignItems: "center", justifyContent: "center" }}>
          <Ionicons name={icon} size={18} color={ic} />
        </View>
        <Text style={{ fontSize: theme.fontSize.md, fontFamily: theme.fonts.semibold, color: danger ? theme.colors.error.base : theme.colors.text.primary }}>
          {label}
        </Text>
      </View>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        {badge != null && (
          <Badge variant={danger ? "error" : "brand"} size="sm">{String(badge)}</Badge>
        )}
        <Ionicons name="chevron-back" size={16} color={theme.colors.text.tertiary} />
      </View>
    </Pressable>
  );
}

function MenuSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionCard}>{children}</View>
    </View>
  );
}

export default function ProfileScreen() {
  const router          = useRouter();
  const insets          = useSafeAreaInsets();
  const { user, signOut } = useAuth();
  const cartCount       = useCartStore((s) => s.itemCount());
  const wishlistCount   = useWishlistStore((s) => s.items.length);
  const orderCount      = useOrderStore((s) => s.orders.length);
  const [signingOut, setSigningOut] = useState(false);

  const handleSignOut = useCallback(async () => {
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
    setSigningOut(true);
    try {
      await signOut();
    } finally {
      setSigningOut(false);
    }
  }, [signOut]);

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{ paddingTop: insets.top + 8, paddingBottom: theme.layout.tabBarHeight + 24 }}
      showsVerticalScrollIndicator={false}>

      {/* ── User card ─────────────────────────────────────────────────── */}
      {user ? (
        <LinearGradient
          colors={theme.gradients.heroPrimary as [string, string, string]}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.9, y: 1 }}
          style={styles.userCard}>
          {/* Avatar */}
          <View style={styles.avatar}>
            <Text style={{ fontSize: 22, fontFamily: theme.fonts.black, color: theme.colors.brand[700] }}>
              {(user.name ?? user.email)?.[0]?.toUpperCase() ?? "U"}
            </Text>
          </View>
          <View style={{ flex: 1, gap: 3 }}>
            <Text style={{ color: "#fff", fontSize: theme.fontSize['2xl'], fontFamily: theme.fonts.black, textAlign: "right" }} numberOfLines={1}>
              {user.name ?? "المستخدم"}
            </Text>
            <Text style={{ color: "rgba(255,255,255,0.60)", fontSize: theme.fontSize.sm, textAlign: "right" }} numberOfLines={1}>
              {user.email}
            </Text>
          </View>
        </LinearGradient>
      ) : (
        <View style={styles.guestCard}>
          <View style={styles.avatarGuest}>
            <Ionicons name="person-outline" size={28} color={theme.colors.brand[400]} />
          </View>
          <View style={{ gap: 6, flex: 1 }}>
            <Text style={{ fontSize: theme.fontSize.xl, fontFamily: theme.fonts.black, color: theme.colors.text.primary, textAlign: "right" }}>
              سجّل دخولك
            </Text>
            <Text style={{ fontSize: theme.fontSize.sm, color: theme.colors.text.tertiary, textAlign: "right" }}>
              للوصول إلى طلباتك ومفضلتك
            </Text>
          </View>
          <View style={{ gap: 8, marginTop: 4 }}>
            <Button variant="primary" size="sm" gradient onPress={() => router.push("/(auth)/login")}>تسجيل الدخول</Button>
            <Button variant="outline" size="sm" onPress={() => router.push("/(auth)/register")}>إنشاء حساب</Button>
          </View>
        </View>
      )}

      {/* ── Account section ───────────────────────────────────────────── */}
      <MenuSection title="حسابي">
        <MenuItem icon="bag-outline"     label="طلباتي"     badge={orderCount || undefined} onPress={() => router.push("/orders")}    />
        <MenuItem icon="heart-outline"   label="المفضلة"    badge={wishlistCount || undefined} onPress={() => router.push("/favorites")} />
        <MenuItem icon="location-outline" label="العناوين"  onPress={() => {}} />
        <MenuItem icon="notifications-outline" label="الإشعارات" onPress={() => {}} />
      </MenuSection>

      {/* ── Support section ───────────────────────────────────────────── */}
      <MenuSection title="الدعم">
        <MenuItem
          icon="logo-whatsapp"
          label="تواصل معنا"
          color="#25D366"
          onPress={() => Linking.openURL("https://wa.me/201112343212?text=مرحباً").catch(() => {})}
        />
        <MenuItem icon="information-circle-outline" label="عن التطبيق"    onPress={() => {}} />
        <MenuItem icon="document-text-outline"      label="سياسة الخصوصية" onPress={() => {}} />
        <MenuItem icon="shield-checkmark-outline"   label="الشروط والأحكام" onPress={() => {}} />
      </MenuSection>

      {/* ── Sign out ──────────────────────────────────────────────────── */}
      {user && (
        <View style={{ paddingHorizontal: theme.layout.pagePaddingH, marginTop: 8 }}>
          <Button variant="danger" size="md" fullWidth loading={signingOut} onPress={handleSignOut}>
            تسجيل الخروج
          </Button>
        </View>
      )}

      {/* Version */}
      <Text style={{ textAlign: "center", fontSize: 11, color: theme.colors.text.disabled, marginTop: 20 }}>
        الصيدلية المتحدة • v1.0.0
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen:      { flex: 1, backgroundColor: theme.colors.bg },
  userCard:    { flexDirection: "row-reverse", alignItems: "center", gap: 14, marginHorizontal: theme.layout.pagePaddingH, marginBottom: 20, padding: 18, borderRadius: theme.radius['2xl'], overflow: "hidden", ...theme.shadow.lg },
  guestCard:   { gap: 12, marginHorizontal: theme.layout.pagePaddingH, marginBottom: 20, padding: 18, backgroundColor: theme.colors.surface, borderRadius: theme.radius['2xl'], ...theme.shadow.card, borderWidth: 1, borderColor: theme.colors.border.default },
  avatar:      { width: 52, height: 52, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.20)", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "rgba(255,255,255,0.35)" },
  avatarGuest: { width: 60, height: 60, borderRadius: 20, backgroundColor: theme.colors.brand[50], alignItems: "center", justifyContent: "center", alignSelf: "flex-end", borderWidth: 1, borderColor: theme.colors.brand[100] },
  section:     { paddingHorizontal: theme.layout.pagePaddingH, marginBottom: 12, gap: 8 },
  sectionTitle:{ fontSize: theme.fontSize.xs, fontFamily: theme.fonts.extrabold, color: theme.colors.text.tertiary, letterSpacing: 0.8, textAlign: "right" },
  sectionCard: { backgroundColor: theme.colors.surface, borderRadius: theme.layout.cardRadius, overflow: "hidden", ...theme.shadow.xs, borderWidth: 1, borderColor: theme.colors.border.default },
  item:        { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14, paddingVertical: 13, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: theme.colors.border.default },
});
