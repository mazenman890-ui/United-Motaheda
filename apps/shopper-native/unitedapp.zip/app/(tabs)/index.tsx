import React, { useCallback, memo } from "react";
import {
  FlatList,
  Linking,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import Animated, { FadeInDown, FadeInUp } from "react-native-reanimated";
import { fetchCategories, fetchFeaturedProducts } from "@/services/productsApi";
import { CategoryCard } from "@/components/CategoryCard";
import { ProductCard } from "@/components/ProductCard";
import { ProductCardSkeleton, CategoryCardSkeleton } from "@/components/ui/Skeleton";
import { theme } from "@/theme";
import { useCartStore } from "@/stores/cart";
import { useAuth } from "@/contexts/AuthContext";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

// ─── Quick Actions ────────────────────────────────────────────────────────────

const QUICK_ACTIONS: { icon: IoniconsName; label: string; color: string; bg: string; route: string }[] = [
  { icon: "scan-outline",        label: "وصفة طبية", color: "#7C3AED", bg: "#FAF5FF", route: "/(tabs)/search"   },
  { icon: "leaf-outline",        label: "فيتامينات",  color: "#059669", bg: "#ECFDF5", route: "/(tabs)/products" },
  { icon: "heart-circle-outline",label: "الأم والطفل",color: "#DB2777", bg: "#FFF1F2", route: "/(tabs)/products" },
  { icon: "pricetag-outline",    label: "العروض",    color: "#D97706", bg: "#FFFBEB", route: "/(tabs)/search"   },
];

const QuickAction = memo(function QuickAction({
  icon, label, color, bg, onPress,
}: { icon: IoniconsName; label: string; color: string; bg: string; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex:           1,
        alignItems:     "center",
        gap:            6,
        opacity:        pressed ? 0.75 : 1,
      })}>
      <View style={{
        width:           52,
        height:          52,
        borderRadius:    16,
        backgroundColor: bg,
        alignItems:      "center",
        justifyContent:  "center",
        borderWidth:     1,
        borderColor:     `${color}22`,
        ...theme.shadow.sm,
      }}>
        <Ionicons name={icon} size={22} color={color} />
      </View>
      <Text style={{ fontSize: 11, fontFamily: theme.fonts.bold, color: theme.colors.text.secondary, textAlign: "center" }}>
        {label}
      </Text>
    </Pressable>
  );
});

// ─── Section Header ───────────────────────────────────────────────────────────

const SectionHeader = memo(function SectionHeader({
  title, icon, accent = theme.colors.brand[600], onMore,
}: { title: string; icon: IoniconsName; accent?: string; onMore?: () => void }) {
  return (
    <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingHorizontal: theme.layout.pagePaddingH }}>
      <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
        <View style={{ width: 28, height: 28, borderRadius: 9, backgroundColor: `${accent}18`, alignItems: "center", justifyContent: "center" }}>
          <Ionicons name={icon} size={14} color={accent} />
        </View>
        <Text style={{ fontSize: theme.fontSize.xl, fontFamily: theme.fonts.black, color: theme.colors.text.primary }}>
          {title}
        </Text>
      </View>
      {onMore && (
        <Pressable onPress={onMore} style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
          <Ionicons name="chevron-back" size={13} color={theme.colors.brand[600]} />
          <Text style={{ fontSize: 12, fontFamily: theme.fonts.bold, color: theme.colors.brand[600] }}>عرض الكل</Text>
        </Pressable>
      )}
    </View>
  );
});

// ─── Promo Banner ─────────────────────────────────────────────────────────────

const PromoBanner = memo(function PromoBanner({ onPress }: { onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ marginHorizontal: theme.layout.pagePaddingH }}>
      <LinearGradient
        colors={["#7C3AED", "#9333EA", "#DB2777"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          borderRadius:    theme.radius['2xl'],
          padding:         20,
          flexDirection:   "row-reverse",
          alignItems:      "center",
          justifyContent:  "space-between",
          overflow:        "hidden",
          ...theme.shadow.md,
        }}>
        {/* Decor */}
        <View style={{ position: "absolute", right: -24, top: -24, width: 100, height: 100, borderRadius: 50, backgroundColor: "rgba(255,255,255,0.07)" }} />
        <View style={{ position: "absolute", left: 30, bottom: -30, width: 80, height: 80, borderRadius: 40, backgroundColor: "rgba(255,255,255,0.05)" }} />

        <View style={{ gap: 4 }}>
          <Text style={{ color: "rgba(255,255,255,0.75)", fontSize: 10, fontFamily: theme.fonts.extrabold, letterSpacing: 1.5 }}>
            برنامج الولاء
          </Text>
          <Text style={{ color: "#fff", fontSize: 17, fontFamily: theme.fonts.black, lineHeight: 24 }}>
            {"اجمع نقاطك\nواحصل على مكافآت"}
          </Text>
        </View>

        <View style={{
          width:           48,
          height:          48,
          borderRadius:    16,
          backgroundColor: "rgba(255,255,255,0.20)",
          alignItems:      "center",
          justifyContent:  "center",
          borderWidth:     1,
          borderColor:     "rgba(255,255,255,0.30)",
        }}>
          <Ionicons name="gift-outline" size={22} color="#fff" />
        </View>
      </LinearGradient>
    </Pressable>
  );
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const router     = useRouter();
  const insets     = useSafeAreaInsets();
  const cartCount  = useCartStore((s) => s.itemCount());
  const { user }   = useAuth();

  const { data: categories = [], refetch: refCats, isLoading: catsLoading } =
    useQuery({ queryKey: ["categories"], queryFn: fetchCategories });

  const { data: featured = [], refetch: refFeat, isLoading: featLoading, isRefetching } =
    useQuery({ queryKey: ["featured"], queryFn: () => fetchFeaturedProducts(10) });

  const onRefresh = useCallback(async () => {
    await Promise.all([refCats(), refFeat()]);
  }, [refCats, refFeat]);

  const greeting = user?.name ? `مرحباً، ${user.name.split(" ")[0]}` : "مرحباً بك";

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.bg }}
      contentContainerStyle={{ paddingBottom: theme.layout.tabBarHeight + 24 }}
      showsVerticalScrollIndicator={false}
      removeClippedSubviews
      refreshControl={
        <RefreshControl
          refreshing={isRefetching}
          onRefresh={onRefresh}
          tintColor={theme.colors.brand[500]}
          colors={[theme.colors.brand[600]]}
        />
      }>

      {/* ── Hero Header ─────────────────────────────────────────────────────── */}
      <LinearGradient
        colors={theme.gradients.heroPrimary as [string, string, string]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={{
          paddingTop:        insets.top + 16,
          paddingBottom:     32,
          paddingHorizontal: theme.layout.pagePaddingH,
          overflow:          "hidden",
        }}>

        {/* Subtle grid */}
        {[0, 1, 2].map((i) => (
          <View key={i} style={{ position: "absolute", left: `${i * 33 + 5}%` as unknown as number, top: 0, bottom: 0, width: 1, backgroundColor: "rgba(255,255,255,0.025)" }} />
        ))}

        {/* Top bar */}
        <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          {/* Brand logo */}
          <View style={{ backgroundColor: "#fff", borderRadius: 14, paddingHorizontal: 12, paddingVertical: 6, ...theme.shadow.sm }}>
            <Image
              source={require("../../assets/logo.png")}
              style={{ width: 110, height: 40 }}
              contentFit="contain"
            />
          </View>

          {/* Action buttons */}
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Pressable
              onPress={() => router.push("/(tabs)/cart")}
              style={{ position: "relative", width: 40, height: 40, borderRadius: 13, backgroundColor: theme.colors.glass, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: theme.colors.glassBorder }}>
              <Ionicons name="bag-outline" size={18} color="rgba(255,255,255,0.90)" />
              {cartCount > 0 && (
                <View style={{ position: "absolute", top: -4, right: -4, backgroundColor: theme.colors.error.base, borderRadius: 8, minWidth: 16, height: 16, alignItems: "center", justifyContent: "center", paddingHorizontal: 3, borderWidth: 1.5, borderColor: theme.colors.hero }}>
                  <Text style={{ color: "#fff", fontSize: 8, fontFamily: theme.fonts.black }}>{cartCount > 9 ? "9+" : cartCount}</Text>
                </View>
              )}
            </Pressable>
            <Pressable style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.colors.glass, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: theme.colors.glassBorder }}>
              <Ionicons name="notifications-outline" size={18} color="rgba(255,255,255,0.75)" />
            </Pressable>
          </View>
        </View>

        {/* Greeting + headline */}
        <Animated.View entering={FadeInUp.duration(400).delay(100)} style={{ gap: 6, marginBottom: 20 }}>
          <Text style={{ color: theme.colors.brand[300], fontSize: 12, fontFamily: theme.fonts.semibold, textAlign: "right" }}>
            {greeting}
          </Text>
          <Text style={{ color: "#fff", fontSize: 22, fontFamily: theme.fonts.black, lineHeight: 30, textAlign: "right" }}>
            {"ابحث عن\nدوائك بسهولة"}
          </Text>
        </Animated.View>

        {/* Search bar (tappable → goes to search tab) */}
        <Pressable
          onPress={() => router.push("/(tabs)/search")}
          style={{
            flexDirection:     "row-reverse",
            alignItems:        "center",
            gap:               10,
            backgroundColor:   "rgba(255,255,255,0.13)",
            borderRadius:      theme.radius['2xl'],
            paddingHorizontal: 14,
            paddingVertical:   13,
            borderWidth:       1,
            borderColor:       "rgba(255,255,255,0.20)",
          }}>
          <Ionicons name="search-outline" size={17} color="rgba(255,255,255,0.70)" />
          <Text style={{ flex: 1, color: "rgba(255,255,255,0.45)", fontSize: 13, fontFamily: theme.fonts.regular, textAlign: "right" }}>
            ابحث عن دواء، كود، أو مستحضر…
          </Text>
          <View style={{ backgroundColor: "rgba(255,255,255,0.16)", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 }}>
            <Text style={{ color: "rgba(255,255,255,0.60)", fontSize: 10, fontFamily: theme.fonts.bold }}>بحث</Text>
          </View>
        </Pressable>
      </LinearGradient>

      {/* ── Trust strip ──────────────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(400).delay(80)} style={{ marginTop: -20, marginHorizontal: 16, marginBottom: 4 }}>
        <View style={{
          backgroundColor:   theme.colors.surface,
          borderRadius:      theme.radius['2xl'],
          paddingVertical:   12,
          paddingHorizontal: 8,
          flexDirection:     "row-reverse",
          ...theme.shadow.lg,
          borderWidth:       1,
          borderColor:       theme.colors.border.default,
        }}>
          {[
            { icon: "flash-outline" as IoniconsName,             label: "توصيل سريع" },
            { icon: "shield-checkmark-outline" as IoniconsName,  label: "أدوية أصلية" },
            { icon: "wallet-outline" as IoniconsName,            label: "الدفع عند الاستلام" },
            { icon: "refresh-outline" as IoniconsName,           label: "إرجاع مضمون" },
          ].map((t, i, arr) => (
            <View key={t.label} style={{ flex: 1, alignItems: "center", gap: 5, borderRightWidth: i < arr.length - 1 ? 1 : 0, borderRightColor: theme.colors.border.default, paddingHorizontal: 2 }}>
              <View style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: theme.colors.brand[50], alignItems: "center", justifyContent: "center" }}>
                <Ionicons name={t.icon} size={14} color={theme.colors.brand[600]} />
              </View>
              <Text style={{ fontSize: 9, fontFamily: theme.fonts.bold, color: theme.colors.text.secondary, textAlign: "center", lineHeight: 12 }}>{t.label}</Text>
            </View>
          ))}
        </View>
      </Animated.View>

      {/* ── Quick Actions ─────────────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(380).delay(130)} style={{ paddingTop: 24, paddingHorizontal: theme.layout.pagePaddingH, gap: 12 }}>
        <Text style={{ fontSize: theme.fontSize.xl, fontFamily: theme.fonts.black, color: theme.colors.text.primary, textAlign: "right" }}>
          تسوق بسرعة
        </Text>
        <View style={{ flexDirection: "row-reverse", gap: 8 }}>
          {QUICK_ACTIONS.map((qa) => (
            <QuickAction
              key={qa.label}
              {...qa}
              onPress={() => {
                if (Platform.OS !== "web") Haptics.selectionAsync();
                router.push(qa.route as Parameters<typeof router.push>[0]);
              }}
            />
          ))}
        </View>
      </Animated.View>

      {/* ── Categories ───────────────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(380).delay(170)} style={{ paddingTop: 28, gap: 14 }}>
        <SectionHeader
          title="تسوق حسب القسم"
          icon="grid-outline"
          onMore={() => router.push("/(tabs)/products")}
        />
        {catsLoading ? (
          <FlatList
            data={[1, 2, 3, 4]}
            horizontal
            inverted
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: theme.layout.pagePaddingH, gap: 10, paddingTop: 4 }}
            keyExtractor={(k) => String(k)}
            renderItem={() => <CategoryCardSkeleton />}
          />
        ) : (
          <FlatList
            data={categories}
            keyExtractor={(c) => c.id}
            horizontal
            inverted
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 4, gap: 10 }}
            removeClippedSubviews
            initialNumToRender={6}
            renderItem={({ item, index }) => (
              <CategoryCard
                category={item}
                gradientIdx={index}
                lang="ar"
                variant="pill"
                onPress={() => router.push({ pathname: "/category/[id]", params: { id: item.id } })}
              />
            )}
          />
        )}
      </Animated.View>

      {/* ── Loyalty Promo Banner ─────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(380).delay(210)} style={{ paddingTop: 26 }}>
        <PromoBanner onPress={() => router.push("/(tabs)/profile")} />
      </Animated.View>

      {/* ── Featured Products ─────────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(380).delay(250)} style={{ paddingTop: 28, gap: 14 }}>
        <SectionHeader
          title="منتجات مميزة"
          icon="star-outline"
          accent={theme.colors.amber[600]}
          onMore={() => router.push("/(tabs)/search")}
        />
        {featLoading ? (
          <FlatList
            data={[1, 2, 3, 4]}
            numColumns={2}
            scrollEnabled={false}
            keyExtractor={(k) => String(k)}
            columnWrapperStyle={{ gap: 10, flexDirection: "row-reverse" }}
            contentContainerStyle={{ paddingHorizontal: theme.layout.pagePaddingH, gap: 10 }}
            renderItem={() => <View style={{ flex: 1 }}><ProductCardSkeleton /></View>}
          />
        ) : (
          <FlatList
            data={featured}
            numColumns={2}
            scrollEnabled={false}
            keyExtractor={(p) => p.id}
            columnWrapperStyle={{ gap: 10, flexDirection: "row-reverse" }}
            contentContainerStyle={{ paddingHorizontal: theme.layout.pagePaddingH, gap: 10 }}
            renderItem={({ item }) => (
              <View style={{ flex: 1 }}>
                <ProductCard
                  product={item}
                  lang="ar"
                  onPress={() => router.push({ pathname: "/product/[id]", params: { id: item.id } })}
                />
              </View>
            )}
          />
        )}
      </Animated.View>

      {/* ── WhatsApp CTA ─────────────────────────────────────────────────────── */}
      <Animated.View entering={FadeInDown.duration(380).delay(290)} style={{ paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 28 }}>
        <LinearGradient
          colors={theme.gradients.heroPrimary as [string, string, string]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ borderRadius: theme.radius['2xl'], padding: 20, alignItems: "center", gap: 10, overflow: "hidden", ...theme.shadow.brand }}>
          <View style={{ position: "absolute", right: -20, top: -20, width: 90, height: 90, borderRadius: 45, backgroundColor: "rgba(255,255,255,0.05)" }} />
          <Text style={{ color: theme.colors.brand[300], fontSize: 10, fontFamily: theme.fonts.extrabold, letterSpacing: 1.8 }}>دعم صيدلاني</Text>
          <Text style={{ fontSize: 18, fontFamily: theme.fonts.black, color: "#fff", textAlign: "center" }}>تحتاج مساعدة؟</Text>
          <Text style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", textAlign: "center", lineHeight: 18 }}>فريقنا الصيدلاني جاهز للرد</Text>
          <Pressable
            onPress={() => Linking.openURL("https://wa.me/201112343212?text=مرحباً،%20أود%20الاستفسار").catch(() => {})}
            style={({ pressed }) => ({
              flexDirection:     "row",
              alignItems:        "center",
              gap:               8,
              backgroundColor:   "#fff",
              borderRadius:      theme.radius.xl,
              paddingHorizontal: 22,
              paddingVertical:   11,
              marginTop:         4,
              opacity:           pressed ? 0.88 : 1,
              ...theme.shadow.md,
            })}>
            <Ionicons name="logo-whatsapp" size={17} color="#25D366" />
            <Text style={{ color: theme.colors.text.primary, fontFamily: theme.fonts.black, fontSize: 13 }}>
              تواصل معنا
            </Text>
          </Pressable>
        </LinearGradient>
      </Animated.View>

    </ScrollView>
  );
}
