import React, { useCallback, useRef, useState } from "react";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useDebounce } from "@/hooks/useDebounce";
import { fetchProducts } from "@/services/productsApi";
import { ProductCard } from "@/components/ProductCard";
import { ProductCardSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { Badge } from "@/components/ui/Badge";
import { theme } from "@/theme";
import type { NativeProduct } from "@/services/productsApi";

type SortKey = "newest" | "price_asc" | "price_desc" | "name_asc";

const SORT_OPTIONS: { key: SortKey; label: string }[] = [
  { key: "newest",     label: "الأحدث" },
  { key: "price_asc",  label: "الأرخص" },
  { key: "price_desc", label: "الأغلى" },
  { key: "name_asc",   label: "أ - ي"  },
];

const QUICK_PILLS = [
  "باراسيتامول", "أموكسيسيلين", "أوميبرازول", "فيتامين C",
  "إيبوبروفين", "ميترونيدازول", "ديكلوفيناك", "أسبيرين",
];

export default function SearchScreen() {
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const inputRef = useRef<TextInput>(null);

  const [query,       setQuery]       = useState("");
  const [sortBy,      setSortBy]      = useState<SortKey>("newest");
  const [inStockOnly, setInStockOnly] = useState(false);

  const debouncedQuery = useDebounce(query.trim(), 320);

  const {
    data,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    isFetching,
  } = useInfiniteQuery({
    queryKey:         ["search", debouncedQuery, sortBy, inStockOnly],
    queryFn:          ({ pageParam = 1 }) =>
      fetchProducts({ search: debouncedQuery, sortBy, inStock: inStockOnly || undefined, page: pageParam, pageSize: 24 }),
    initialPageParam: 1,
    getNextPageParam: (last) => last.hasNextPage ? last.currentPage + 1 : undefined,
    enabled:          debouncedQuery.length > 0,
    staleTime:        2 * 60 * 1000,
  });

  const allResults  = data?.pages.flatMap((p) => p.products) ?? [];
  const totalCount  = data?.pages[0]?.totalCount ?? 0;
  const searching   = isLoading || (isFetching && allResults.length === 0);

  const handleClear = useCallback(() => {
    setQuery("");
    inputRef.current?.focus();
  }, []);

  const handleLoadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage) fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  const handleSort = useCallback((key: SortKey) => {
    setSortBy(key);
  }, []);

  const renderProduct = useCallback(({ item }: { item: NativeProduct | null }) =>
    item == null ? (
      <View style={{ flex: 1 }}><ProductCardSkeleton /></View>
    ) : (
      <View style={{ flex: 1 }}>
        <ProductCard
          product={item}
          lang="ar"
          onPress={() => router.push({ pathname: "/product/[id]", params: { id: item.id } })}
        />
      </View>
    ),
  [router]);

  const keyExtractor = useCallback((item: NativeProduct | null, index: number) =>
    item?.id ?? String(index),
  []);

  const listData: (NativeProduct | null)[] = searching && allResults.length === 0
    ? Array(8).fill(null)
    : allResults;

  return (
    <View style={styles.screen}>

      {/* ── Header / Search bar ─────────────────────────────────────────── */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.searchRow}>
          <Ionicons name="search-outline" size={18} color={theme.colors.text.tertiary} style={{ marginRight: 10 }} />
          <TextInput
            ref={inputRef}
            style={styles.input}
            placeholder="ابحث عن دواء، كود، أو منتج…"
            placeholderTextColor={theme.colors.text.tertiary}
            value={query}
            onChangeText={setQuery}
            returnKeyType="search"
            autoCorrect={false}
            textAlign="right"
          />
          {query.length > 0 && (
            <Pressable onPress={handleClear} hitSlop={10}>
              <Ionicons name="close-circle" size={18} color={theme.colors.text.tertiary} />
            </Pressable>
          )}
        </View>

        {/* Chips — visible only when there's a query */}
        {debouncedQuery.length > 0 && (
          <View style={styles.chips}>
            <Pressable
              onPress={() => setInStockOnly(!inStockOnly)}
              style={[styles.chip, inStockOnly && styles.chipActive]}>
              <Ionicons
                name={inStockOnly ? "checkmark-circle" : "checkmark-circle-outline"}
                size={13}
                color={inStockOnly ? "#fff" : theme.colors.brand[600]}
              />
              <Text style={[styles.chipText, inStockOnly && styles.chipTextActive]}>متاح</Text>
            </Pressable>

            {SORT_OPTIONS.map((s) => (
              <Pressable
                key={s.key}
                onPress={() => handleSort(s.key)}
                style={[styles.chip, sortBy === s.key && styles.chipActive]}>
                <Text style={[styles.chipText, sortBy === s.key && styles.chipTextActive]}>{s.label}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>

      {/* ── Content ─────────────────────────────────────────────────────── */}
      {debouncedQuery.length === 0 ? (
        <View style={{ flex: 1, paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 28, gap: 16 }}>
          <Text style={styles.pillsTitle}>بحث سريع</Text>
          <View style={styles.pillsWrap}>
            {QUICK_PILLS.map((pill) => (
              <Pressable
                key={pill}
                onPress={() => setQuery(pill)}
                style={({ pressed }) => [styles.pill, pressed && { opacity: 0.7 }]}>
                <Ionicons name="search-outline" size={12} color={theme.colors.text.tertiary} />
                <Text style={styles.pillText}>{pill}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      ) : (
        <FlatList
          data={listData}
          keyExtractor={keyExtractor}
          numColumns={2}
          columnWrapperStyle={styles.colWrapper}
          contentContainerStyle={[styles.list, { paddingBottom: theme.layout.tabBarHeight + 24 }]}
          removeClippedSubviews
          initialNumToRender={8}
          maxToRenderPerBatch={12}
          windowSize={5}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
          ListHeaderComponent={
            !searching && allResults.length > 0 ? (
              <View style={styles.resultsHeader}>
                <Badge variant="brand">{`${totalCount.toLocaleString()} نتيجة`}</Badge>
              </View>
            ) : null
          }
          ListEmptyComponent={
            !searching ? (
              <EmptyState
                icon="search-outline"
                title="لا توجد نتائج"
                description={`لم نجد منتجات تطابق "${debouncedQuery}"`}
              />
            ) : null
          }
          ListFooterComponent={
            isFetchingNextPage ? (
              <View style={styles.footerLoader}>
                <View style={{ flexDirection: "row", gap: 6 }}>
                  {[0, 1, 2].map((i) => (
                    <View
                      key={i}
                      style={{
                        width:           6,
                        height:          6,
                        borderRadius:    3,
                        backgroundColor: theme.colors.brand[400],
                        opacity:         0.4 + i * 0.2,
                      }}
                    />
                  ))}
                </View>
              </View>
            ) : null
          }
          renderItem={renderProduct}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen:       { flex: 1, backgroundColor: theme.colors.bg },
  header:       { backgroundColor: theme.colors.surface, paddingHorizontal: theme.layout.pagePaddingH, paddingBottom: 12, gap: 12, borderBottomWidth: 1, borderBottomColor: theme.colors.border.default, ...theme.shadow.xs },
  searchRow:    { flexDirection: "row", alignItems: "center", backgroundColor: theme.colors.muted, borderRadius: theme.radius.xl, paddingHorizontal: 14, height: 48, borderWidth: 1, borderColor: theme.colors.border.default },
  input:        { flex: 1, fontSize: theme.fontSize.md, fontFamily: theme.fonts.regular, color: theme.colors.text.primary, textAlign: "right" },
  chips:        { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  chip:         { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: theme.radius.full, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border.default },
  chipActive:   { backgroundColor: theme.colors.brand[600], borderColor: theme.colors.brand[600] },
  chipText:     { fontSize: 12, fontFamily: theme.fonts.bold, color: theme.colors.brand[700] },
  chipTextActive: { color: "#fff" },
  // Empty state — pills
  pillsTitle:   { fontSize: theme.fontSize.xl, fontFamily: theme.fonts.black, color: theme.colors.text.primary, textAlign: "right" },
  pillsWrap:    { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  pill:         { flexDirection: "row-reverse", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: theme.radius.full, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border.default, ...theme.shadow.xs },
  pillText:     { fontSize: 13, fontFamily: theme.fonts.semibold, color: theme.colors.text.primary },
  // Results
  list:         { paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 16, gap: 10 },
  colWrapper:   { gap: 10, flexDirection: "row-reverse" },
  resultsHeader: { flexDirection: "row-reverse", alignItems: "center", marginBottom: 4 },
  footerLoader: { paddingVertical: 20, alignItems: "center" },
});
