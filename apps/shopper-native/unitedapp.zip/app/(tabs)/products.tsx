import React from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Animated, { FadeInDown } from "react-native-reanimated";
import { fetchCategories } from "@/services/productsApi";
import { CategoryCard } from "@/components/CategoryCard";
import { CategoryCardSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { theme } from "@/theme";

export default function ProductsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const { data: categories = [], isLoading, isError, refetch } = useQuery({
    queryKey: ["categories"],
    queryFn:  fetchCategories,
  });

  return (
    <View style={[styles.screen, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>الأصناف</Text>
        <Text style={styles.subtitle}>{categories.length} قسم</Text>
      </View>

      {/* Grid */}
      {isLoading ? (
        <FlatList
          data={Array(8).fill(null)}
          numColumns={2}
          keyExtractor={(_, i) => String(i)}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.list}
          renderItem={() => (
            <View style={{ flex: 1 }}>
              <CategoryCardSkeleton />
            </View>
          )}
        />
      ) : isError ? (
        <EmptyState
          icon="wifi-outline"
          title="تعذر التحميل"
          description="تحقق من اتصالك بالإنترنت وحاول مرة أخرى"
          actionLabel="إعادة المحاولة"
          onAction={() => refetch()}
        />
      ) : categories.length === 0 ? (
        <EmptyState icon="grid-outline" title="لا توجد أقسام" description="لا توجد أقسام متاحة حالياً" />
      ) : (
        <FlatList
          data={categories}
          numColumns={2}
          keyExtractor={(c) => c.id}
          columnWrapperStyle={styles.row}
          contentContainerStyle={[styles.list, { paddingBottom: theme.layout.tabBarHeight + 24 }]}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews
          renderItem={({ item, index }) => (
            <Animated.View
              entering={FadeInDown.duration(300).delay(index * 40)}
              style={{ flex: 1 }}>
              <CategoryCard
                category={item}
                gradientIdx={index}
                lang="ar"
                variant="tile"
                onPress={() => router.push({ pathname: "/category/[id]", params: { id: item.id } })}
              />
            </Animated.View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen:   { flex: 1, backgroundColor: theme.colors.bg },
  header:   { paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 16, paddingBottom: 14, gap: 2 },
  title:    { fontSize: theme.fontSize['4xl'], fontFamily: theme.fonts.black, color: theme.colors.text.primary, textAlign: "right" },
  subtitle: { fontSize: theme.fontSize.sm, fontFamily: theme.fonts.regular, color: theme.colors.text.tertiary, textAlign: "right" },
  list:     { paddingHorizontal: theme.layout.pagePaddingH, paddingTop: 4, gap: 10 },
  row:      { gap: 10, flexDirection: "row-reverse" },
});
