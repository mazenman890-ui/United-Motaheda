import React, { useEffect, useCallback } from "react";
import { Platform, Pressable, Text, View } from "react-native";
import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  interpolate,
  Extrapolation,
  FadeIn,
} from "react-native-reanimated";
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { useCartStore } from "@/stores/cart";
import { theme } from "@/theme";

type IoniconsName = React.ComponentProps<typeof Ionicons>["name"];

interface TabConfig {
  active:   IoniconsName;
  inactive: IoniconsName;
  label:    string;
}

const TAB_CONFIG: Record<string, TabConfig> = {
  index:    { active: "home",             inactive: "home-outline",          label: "الرئيسية" },
  search:   { active: "search",           inactive: "search-outline",        label: "بحث"      },
  products: { active: "grid",             inactive: "grid-outline",          label: "الأصناف"  },
  cart:     { active: "bag",              inactive: "bag-outline",           label: "السلة"    },
  profile:  { active: "person-circle",   inactive: "person-circle-outline", label: "حسابي"    },
};

// ─── Single Tab Item ──────────────────────────────────────────────────────────

interface TabItemProps {
  name:    string;
  focused: boolean;
  badge?:  number;
  onPress: () => void;
}

function TabItem({ name, focused, badge, onPress }: TabItemProps) {
  const cfg   = TAB_CONFIG[name] ?? TAB_CONFIG.index;
  const scale = useSharedValue(1);
  const dot   = useSharedValue(focused ? 1 : 0);

  useEffect(() => {
    scale.value = withSpring(focused ? 1.12 : 1, theme.animation.spring.snappy);
    dot.value   = withTiming(focused ? 1 : 0, { duration: theme.animation.duration.normal });
  }, [focused, dot, scale]);

  const iconAnim = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const dotAnim = useAnimatedStyle(() => ({
    opacity:   dot.value,
    transform: [{ scaleX: interpolate(dot.value, [0, 1], [0, 1], Extrapolation.CLAMP) }],
  }));

  const activeColor   = theme.colors.brand[600];
  const inactiveColor = theme.colors.slate[400];
  const iconColor     = focused ? activeColor : inactiveColor;

  const handlePress = useCallback(() => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    }
    onPress();
  }, [onPress]);

  return (
    <Pressable
      onPress={handlePress}
      hitSlop={8}
      style={{
        flex:           1,
        alignItems:     "center",
        justifyContent: "center",
        paddingVertical: 10,
        gap:            4,
      }}>

      {/* Active background pill */}
      {focused && (
        <Animated.View
          entering={FadeIn.duration(150)}
          style={{
            position:        "absolute",
            top:             4,
            bottom:          4,
            left:            6,
            right:           6,
            borderRadius:    14,
            backgroundColor: `${theme.colors.brand[600]}14`,
          }}
        />
      )}

      {/* Icon */}
      <View style={{ position: "relative" }}>
        <Animated.View style={iconAnim}>
          <Ionicons name={focused ? cfg.active : cfg.inactive} size={22} color={iconColor} />
        </Animated.View>

        {/* Cart / notification badge */}
        {badge != null && badge > 0 && (
          <View
            style={{
              position:          "absolute",
              top:               -5,
              right:             -7,
              minWidth:          16,
              height:            16,
              borderRadius:      8,
              backgroundColor:   theme.colors.error.base,
              alignItems:        "center",
              justifyContent:    "center",
              paddingHorizontal: 3,
              borderWidth:       1.5,
              borderColor:       "#fff",
            }}>
            <Text style={{ color: "#fff", fontSize: 9, fontFamily: theme.fonts.black, lineHeight: 11 }}>
              {badge > 9 ? "9+" : badge}
            </Text>
          </View>
        )}
      </View>

      {/* Label */}
      <Text
        style={{
          fontSize:   10,
          fontFamily: focused ? theme.fonts.bold : theme.fonts.regular,
          color:      iconColor,
          letterSpacing: 0.2,
        }}
        numberOfLines={1}>
        {cfg.label}
      </Text>

      {/* Active dot */}
      <Animated.View
        style={[{
          width:         4,
          height:        4,
          borderRadius:  2,
          backgroundColor: activeColor,
          marginTop:     -2,
        }, dotAnim]}
      />
    </Pressable>
  );
}

// ─── Floating Tab Bar ─────────────────────────────────────────────────────────

function FloatingTabBar({ state, navigation }: BottomTabBarProps) {
  const insets    = useSafeAreaInsets();
  const cartCount = useCartStore((s) => s.itemCount());

  const onPress = useCallback(
    (route: { key: string; name: string }, focused: boolean) => {
      const event = navigation.emit({
        type:              "tabPress",
        target:            route.key,
        canPreventDefault: true,
      });
      if (!focused && !event.defaultPrevented) {
        navigation.navigate(route.name);
      }
    },
    [navigation],
  );

  return (
    <View
      style={{
        position:  "absolute",
        bottom:    Math.max(insets.bottom, 8) + 4,
        left:      16,
        right:     16,
        zIndex:    theme.zIndex.sticky,
      }}
      pointerEvents="box-none">
      <BlurView
        intensity={80}
        tint="light"
        style={{
          borderRadius: 24,
          overflow:     "hidden",
          borderWidth:  1,
          borderColor:  "rgba(255,255,255,0.70)",
          ...theme.shadow.float,
        }}>
        <View
          style={{
            flexDirection:     "row",
            alignItems:        "center",
            paddingHorizontal: 4,
            paddingVertical:   2,
            backgroundColor:   "rgba(248,250,252,0.88)",
          }}>
          {state.routes.map((route, index) => {
            const focused = state.index === index;
            return (
              <TabItem
                key={route.key}
                name={route.name}
                focused={focused}
                badge={route.name === "cart" ? cartCount : undefined}
                onPress={() => onPress(route, focused)}
              />
            );
          })}
        </View>
      </BlurView>
    </View>
  );
}

// ─── Layout ───────────────────────────────────────────────────────────────────

export default function TabLayout() {
  return (
    <Tabs
      tabBar={(props) => <FloatingTabBar {...props} />}
      screenOptions={{ headerShown: false }}>
      <Tabs.Screen name="index"    />
      <Tabs.Screen name="search"   />
      <Tabs.Screen name="products" />
      <Tabs.Screen name="cart"     />
      <Tabs.Screen name="profile"  />
    </Tabs>
  );
}
